#pragma once

#include <vtkObject.h>
#include <vtkPNGReader.h>
#include "vtkImageViewer2.h"
#include<vtkImageData.h>
#include <vtkSmartPointer.h>
#include<vtkImageIterator.h>
#include<vtkRenderWindowInteractor.h>
void FigureTraversal();