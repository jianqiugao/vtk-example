#pragma once

#include <vtkSmartPointer.h>
#include <vtkAngleWidget.h>
#include <vtkAngleRepresentation2D.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkSphereSource.h>
#include <vtkCamera.h>
#include <vtkRenderer.h>
#include <vtkRenderWindow.h>
#include <vtkPolyDataMapper.h>
#include<vtkProperty.h>
#include<vtkAngleRepresentation3D.h>
#include<vtkAngleRepresentation.h>

void angelwidget();