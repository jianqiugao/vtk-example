#pragma once

#include<vtkSphereSource.h>
#include<vtkMassProperties.h>
#include<vtkDijkstraGraphGeodesicPath.h>
#include<vtkPolyDataNormals.h>
#include<vtkArrowSource.h>
#include<vtkGlyph3D.h>
#include<vtkMaskPoints.h>
#include <vtkDijkstraGraphGeodesicPath.h>
#include <vtkPolyDataMapper.h>
#include <vtkActor.h>
#include<vtkDoubleArray.h>
#include <vtkPointData.h>
#include <vtkProperty.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>


void dijsearch();