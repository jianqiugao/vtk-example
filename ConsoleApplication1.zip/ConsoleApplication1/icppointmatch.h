#pragma once
#include<vtkPolyDataReader.h>
#include<iostream>
#include<vtkSmartPointer.h>
#include<vtkTransform.h>
#include<vtkTransformPolyDataFilter.h>
#include<vtkVertexGlyphFilter.h>
#include<vtkIterativeClosestPointTransform.h>
#include<vtkLandmarkTransform.h>
#include<vtkPolyDataMapper.h>
#include<vtkActor.h>
#include<vtkProperty.h>
#include<vtkRenderer.h>
#include<vtkRenderWindowInteractor.h>
#include<vtkRenderWindow.h>

void icppointmatcg();