#pragma once

#include <CellPickerInteractorStyle.h>
#include <vtkSphereSource.h>
#include <vtkPolyDataMapper.h>

void pickTriangelGridOnSphere();