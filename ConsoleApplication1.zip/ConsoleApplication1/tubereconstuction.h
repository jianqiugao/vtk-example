#pragma once
#include <iostream> 
#include <fstream>
//#include <opencv2/opencv.hpp>
//#include <opencv2/core/core.hpp> 
//#include<opencv2/highgui/highgui.hpp> 
//#include <opencv2/imgproc/imgproc.hpp>
#include <math.h>
#include <vector>
#include <vtkActor.h>
#include <vtkCamera.h>
#include <vtkCellArray.h>
#include <vtkPoints.h>
#include <vtkPolyData.h>
#include <vtkPolyDataMapper.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>
#include <vtkProperty.h>
#include <vtkTubeFilter.h>
#include <vtkParametricSpline.h>
#include <vtkParametricFunctionSource.h>
#include <vtkSmartPointer.h>
#include<vtkParametricSpline.h>
#include<vtkTubeFilter.h>
#include<vtkParametricFunctionSource.h>


void tubereconstruction();



