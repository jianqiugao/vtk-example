#pragma once
#include<vtkConeSource.h>
#include<vtkPolyDataMapper.h>
#include<vtkActor.h>
#include<vtkSmartPointer.h>
#include<vtkRenderer.h>
#include<vtkRenderWindow.h>
#include<vtkRenderWindowInteractor.h>
#include<vtkSphereSource.h>
#include<vtkProperty.h>
#include<vtkPNGReader.h>
#include<vtkImageViewer2.h>
#include<vtkContourWidget.h>
#include<vtkOrientedGlyphContourRepresentation.h>
#include<vtkPolygonalSurfacePointPlacer.h>
#include<vtkPointPlacer.h>

void vtktest();
void readimageanddrawline();