#pragma once

#include<vtkTextActor.h>
#include <vtkTextRepresentation.h>
#include<vtkTextProperty.h>
#include<vtkRenderer.h>
#include<vtkTextActor.h>
#include<vtkTextRepresentation.h>
#include<vtkTextWidget.h>
#include <vtkSmartPointer.h>
#include<vtkRenderWindow.h>
#include<vtkRenderWindowInteractor.h>

void wordpresent();
